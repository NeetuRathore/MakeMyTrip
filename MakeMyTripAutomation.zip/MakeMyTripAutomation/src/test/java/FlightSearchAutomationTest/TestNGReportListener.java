package FlightSearchAutomationTest;

import java.io.File;

import org.testng.IExecutionListener;

public class TestNGReportListener implements IExecutionListener{
	
	@Override
    public void onExecutionStart() {
        // Not needed for this example
    }

	@Override
    public void onExecutionFinish() {
		// Determine the base directory of your project
        String baseDirectory = System.getProperty("user.dir");

        // Define the relative path to the TestNG report file
        String reportRelativePath = "test-output/emailable-report.html";

        // Concatenate the base directory and the relative path
        String reportAbsolutePath = baseDirectory + File.separator + reportRelativePath;

        // Generate the URL based on the file path
        String reportURL = "file://" + reportAbsolutePath;

        // Print the URL to the console
        System.out.println("TestNG report URL: " + reportURL);
	}
    
}

