package FlightSearchAutomationTest;

import java.io.File;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;
import org.testng.annotations.*;

import io.qameta.allure.Attachment;
import io.qameta.allure.testng.*;

@Listeners({AllureTestNg.class, TestNGReportListener.class})
public class MakeMyTripFlightSearch {
	
	WebDriver driver;

    @BeforeTest
    public void setup() {
    	ChromeOptions options = new ChromeOptions();
		options.addArguments("--incognito");
		options.addArguments("--disable-notifications");
		options.addArguments("--disable-extensions");
		options.addArguments("--disable-blink-features=AutomationControlled");
		options.addArguments("--disable-extensions");
        driver = new ChromeDriver(options);
        
    }
    
    @Test
    public void searchFlights() {
    	driver.manage().window().maximize();

            // Open MakeMyTrip website
            driver.get("https://www.makemytrip.com/");

            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); 
            
         // Handle any additional pop-ups that might appear
            try {
                // Switch to iframe if the pop-up is within an iframe
            	 wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.cssSelector("iframe[title^='notification-frame']")));
            	 wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#webklipper-publisher-widget-container-notification-close-div"))).click();
                
            	 // Switch back to the main content if we switched to an iframe 
            	 driver.switchTo().defaultContent();
            	 
            } catch (Exception e) {
                // If no additional pop-up appears, continue
            }

            // Click on the Flights tab
            try {
            	WebElement flightsTab = driver.findElement(By.xpath("//span[text()='Flights']"));
                flightsTab.click();
            } catch (Exception e) {
                // If no additional pop-up appears, continue
            	wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("section > span.commonModal__close"))).click();
            	WebElement flightsTab = driver.findElement(By.xpath("//span[text()='Flights']"));
                flightsTab.click();
            }
    
            // Ensure the One-Way trip is selected
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[text()='One Way']")));
            WebElement oneWayTrip = driver.findElement(By.xpath("//li[text()='One Way']"));
            oneWayTrip.click();

            // Enter the departure city (Mumbai)
            WebElement fromInput = driver.findElement(By.id("fromCity"));
            fromInput.click();
            WebElement fromSearch = driver.findElement(By.xpath("//input[@placeholder='From']"));
            fromSearch.sendKeys("Mumbai");
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//p[contains(text(), 'Mumbai, India')]"))).click();

            // Enter the destination city (Bangalore)
            WebElement toInput = driver.findElement(By.id("toCity"));
            toInput.click();
            WebElement toSearch = driver.findElement(By.xpath("//input[@placeholder='To']"));
            toSearch.sendKeys("Bangalore");
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//p[contains(text(), 'Bengaluru, India')]"))).click();

            // Select the current date
            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("E MMM dd yyyy");
            String formattedDate = now.format(formatter);
            WebElement datePicker = driver.findElement(By.xpath("//div[@aria-label='" + formattedDate + "']"));
            datePicker.click();

            // Click the search button
            WebElement searchButton = driver.findElement(By.xpath("//a[text()='Search']"));
            searchButton.click();

            // Wait for search results to load
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='listingCard  appendBottom5']")));
            
            // Extract flight details
            List<WebElement> flights = driver.findElements(By.xpath("//div[@class='listingCard  appendBottom5']"));
            System.out.println("Found " + flights.size() + " flights from Mumbai to Bangalore:");

            for (WebElement flight : flights) {
                String airline = flight.findElement(By.xpath(".//p[@class='boldFont blackText airlineName']")).getText();
                String departureTime = flight.findElement(By.xpath(".//div[@class='flexOne timeInfoLeft']/p/span[1]")).getText();
                String arrivalTime = flight.findElement(By.xpath(".//div[@class='flexOne timeInfoRight']/p/span[1]")).getText();
                String price = flight.findElement(By.xpath(".//div[contains(@class,'clusterViewPrice')][1]")).getText();

                System.out.println("Airline: " + airline);
                System.out.println("Departure Time: " + departureTime);
                System.out.println("Arrival Time: " + arrivalTime);
                System.out.println("Price: " + price);
                System.out.println("------------------------------------------");
            }
    }  
    
    @Attachment(value = "Page screenshot", type = "image/png")
    public byte[] saveScreenshotPNG() {
        return ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
    }
    
    @AfterMethod
    public void takeScreenshotOnFailure(ITestResult result) {
        if (ITestResult.FAILURE == result.getStatus()) {
            saveScreenshotPNG();
        }
    }
    
    @Attachment
    public String logOutput(List<String> outputList) {
        String output = ""; 
        for (String o : outputList) 
            output += o + "<br/>"; 
        return output;
    }
    
    @AfterTest
    public void tearDown() {
        driver.quit();
    }

}



