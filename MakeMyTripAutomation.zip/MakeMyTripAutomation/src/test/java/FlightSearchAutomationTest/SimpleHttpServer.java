package FlightSearchAutomationTest;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import fi.iki.elonen.NanoHTTPD;

public class SimpleHttpServer extends NanoHTTPD {
	
	private final String reportDir;

    public SimpleHttpServer(int port, String reportDir) throws IOException {
        super(port);
        this.reportDir = reportDir;
    }

    @Override
    public Response serve(IHTTPSession session) {
        String uri = session.getUri();
        try {
            if (uri.equals("/")) {
                uri = "/index.html";
            }
            byte[] fileBytes = Files.readAllBytes(Paths.get(reportDir + uri));
            String mimeType = Files.probeContentType(Paths.get(reportDir + uri));
            return newFixedLengthResponse(Response.Status.OK, mimeType, new String(fileBytes));
        } catch (IOException e) {
            e.printStackTrace();
            return newFixedLengthResponse(Response.Status.NOT_FOUND, NanoHTTPD.MIME_PLAINTEXT, "File not found");
        }
    }

}
